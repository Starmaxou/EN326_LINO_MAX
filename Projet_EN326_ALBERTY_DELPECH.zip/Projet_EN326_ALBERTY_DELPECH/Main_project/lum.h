#ifndef __LUM_H
#define __LUM_H

#define pin_lum_in A0
uint16_t readLum( void );

#endif